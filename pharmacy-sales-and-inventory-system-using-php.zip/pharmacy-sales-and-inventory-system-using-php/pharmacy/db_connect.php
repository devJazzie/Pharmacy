<?php

$conn = new mysqli('localhost', 'root', '', 'pharmacy_db') or die("Could not connect to MySQL: " . mysqli_error($conn));

?>